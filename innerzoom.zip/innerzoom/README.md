# Example
An example greeter plugin